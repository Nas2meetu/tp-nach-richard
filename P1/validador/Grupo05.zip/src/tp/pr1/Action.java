package tp.pr1;

/**
*
* @author Ignacio Cerda Sanchez
* @author Ricardo Eugui Fernandez
* @version 1
*
*/


public enum Action {
	
	 /**
	  *  Define valid instructions for Wall·E
	  */

	MOVE, TURN, HELP, QUIT, UNKNOWN 
		
}
	

