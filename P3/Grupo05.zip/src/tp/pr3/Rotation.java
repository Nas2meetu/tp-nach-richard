package tp.pr3;

/**
*
* @author Ignacio Cerda Sanchez
* @author Ricardo Eugui Fernandez
* @version 1
*
*/


public enum Rotation {
	/**
	 * Define valid rotation for Wall·E
	 */
		LEFT, RIGHT, UNKNONW
}
